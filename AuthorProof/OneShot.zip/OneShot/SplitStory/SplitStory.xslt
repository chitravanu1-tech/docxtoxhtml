<?xml version="1.0" encoding="UTF-8"?>
<!-- Added to revove the tab space between li and p on 6-1-2021 -->
<!-- Added to retain the running head FontStyle='Regular' from indd on 10-8-2022 -->
<!-- Added to avoid the paramerge on 27-10-2022 -->
<!-- Added to avoid to the lowercase on 18-1-2023 -->
<!-- commented to avoid the leading space issue Azure 5769 on 18-1-2023-->
<!-- Added to avoid the CharacterStyleRange[@Capitalization='Normal'] from indd Azure 7424 on 04-04-2023 -->
<!-- Added to remove the empty paragraph for figure on 18-5-2023 -->
<!--lowercase not Changed for change(insert) inside CharacterStyleRange Azure 9449 on 12-7-2023-->
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:xs="http://www.w3.org/2001/XMLSchema" exclude-result-prefixes="xs"
    xmlns:idPkg="http://ns.adobe.com/AdobeInDesign/idml/1.0/packaging" version="2.0">

    <xsl:output method="xml" name="xml" standalone="yes" indent="yes"/>
    <xsl:preserve-space elements="Content"/>


    <xsl:template match="node() | @*">
        <xsl:copy>
            <xsl:apply-templates select="node() | @*"/>
        </xsl:copy>
    </xsl:template>

    <xsl:template match="idPkg:Story">
        <xsl:variable name="Self" select="child::Story/@Self"/>
        <xsl:variable name="M" select="concat('Story_', $Self, '.xml')"/>
        <xsl:variable name="filename" select="concat('output/', $M)"/>
        <xsl:result-document href="{$filename}" format="xml">
            <xsl:copy>
                <xsl:apply-templates select="@* | node()"/>
            </xsl:copy>
        </xsl:result-document>
    </xsl:template>
    <!--Added to remove the character style space on 27-08-2021-->
    <xsl:template match="CharacterStyleRange/@AppliedCharacterStyle">
        <xsl:attribute name="AppliedCharacterStyle">
            <xsl:value-of select="normalize-space(.)"/>
        </xsl:attribute>
    </xsl:template>
    <!--End-->
    <!--Added to avoid the normal style in headings 03-09-2021-->
    <!--<xsl:template match="CharacterStyleRange[@FontStyle='Regular']/@FontStyle"/>-->
    <!-- Added to retain the running head FontStyle='Regular' from indd on 10-8-2022 -->
    <xsl:template match="CharacterStyleRange[@FontStyle='Regular'][child::FormattingChange]/@FontStyle"/>
    <xsl:template match="ParagraphStyleRange[@Wchange = 'parainserted']">
        <xsl:variable name="parentStory" select="@ParentStory"/>
        <xsl:if
            test="preceding::ParagraphStyleRange[@ParentStory = $parentStory][1][not(ancestor::Note | ancestor::FootNote)][count(descendant::Br[not(ancestor::Note | ancestor::Footnote)]) = 0]">
            <xsl:element name="ParagraphStyleRange">
                <xsl:attribute name="AppliedParagraphStyle" select="@AppliedParagraphStyle"/>
                <xsl:element name="CharacterStyleRange">
                    <xsl:attribute name="AppliedCharacterStyle"
                        select="'CharacterStyle/$ID/[No character style]'"/>
                    <xsl:element name="Br"/>
                </xsl:element>
            </xsl:element>
        </xsl:if>
        <!--<xsl:copy>
            <xsl:apply-templates select="@* | node()"/>
        </xsl:copy>-->
        <!-- Added to avoid the paramerge on 27-10-2022 -->
        <xsl:copy>
            <xsl:apply-templates select="@*"/>
            <xsl:variable name="RuleAboveLineWeight" select="@RuleAboveLineWeight"/>
            <!--<xsl:variable name="prepara" select="preceding::ParagraphStyleRange[1][@RuleAboveLineWeight]/@RuleAboveLineWeight"/>           
            <xsl:variable name="followpara" select="following::ParagraphStyleRange[1][@RuleAboveLineWeight]/@RuleAboveLineWeight"/>-->
            <xsl:variable name="prepara">
                <xsl:if test="preceding::ParagraphStyleRange[1][@RuleAboveLineWeight][@RuleAboveLineWeight = $RuleAboveLineWeight]">
                    <xsl:value-of select="$RuleAboveLineWeight + 0.001"/>
                </xsl:if>
            </xsl:variable>         
            <xsl:variable name="followpara">
                <xsl:if test="following::ParagraphStyleRange[1][@RuleAboveLineWeight][@RuleAboveLineWeight = $prepara]">
                    <xsl:value-of select="$prepara + 0.001"/>
                </xsl:if>
            </xsl:variable>
            
            <xsl:choose>
                <xsl:when test="self::ParagraphStyleRange[@Wchange = 'parainserted']/string-length(@RuleAboveLineWeight) &gt; 0">
                    <xsl:attribute name="RuleAboveLineWeight">
                        <xsl:choose>
                            <xsl:when test="preceding::ParagraphStyleRange[1][not(@Wchange = 'parainserted')][@RuleAboveLineWeight][@RuleAboveLineWeight = $RuleAboveLineWeight] and following::ParagraphStyleRange[1][not(@Wchange = 'parainserted')][@RuleAboveLineWeight][@RuleAboveLineWeight = $RuleAboveLineWeight]">
                                <xsl:if test="string-length($RuleAboveLineWeight) &gt; 0">
                                <xsl:value-of select="$RuleAboveLineWeight + 0.001"/>
                                </xsl:if>
                            </xsl:when>
                            <xsl:when test="preceding::ParagraphStyleRange[1][not(@Wchange = 'parainserted')][@RuleAboveLineWeight][@RuleAboveLineWeight = $RuleAboveLineWeight] and following::ParagraphStyleRange[1][@Wchange = 'parainserted'][@RuleAboveLineWeight][@RuleAboveLineWeight = $RuleAboveLineWeight]">
                                <xsl:if test="string-length($prepara) &gt; 0">
                                <xsl:value-of select="$prepara + 0.001"/>
                                </xsl:if>
                            </xsl:when>
                            <xsl:when test="preceding::ParagraphStyleRange[1][@Wchange = 'parainserted'][@RuleAboveLineWeight][@RuleAboveLineWeight = $RuleAboveLineWeight] and following::ParagraphStyleRange[1][not(@Wchange = 'parainserted')][@RuleAboveLineWeight][@RuleAboveLineWeight = $RuleAboveLineWeight]">
                                <xsl:if test="string-length($followpara) &gt; 0">
                                <xsl:value-of select="$followpara + 0.001"/>
                                </xsl:if>
                            </xsl:when>
                            <!--<xsl:when test="preceding::ParagraphStyleRange[1][@RuleAboveLineWeight][@RuleAboveLineWeight = $RuleAboveLineWeight] and following::ParagraphStyleRange[1][@RuleAboveLineWeight][@RuleAboveLineWeight = $prepara]">
                            <xsl:value-of select="$followpara"/>
                        </xsl:when>-->
                            <xsl:when test="preceding::ParagraphStyleRange[1][not(@RuleAboveLineWeight)] and following::ParagraphStyleRange[1][not(@RuleAboveLineWeight)]">
                                <xsl:value-of select="'0.001'"/>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:value-of select="@RuleAboveLineWeight"/>
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:attribute>
                </xsl:when>
                <xsl:otherwise>
                <xsl:attribute name="RuleAboveLineWeight">
                    <xsl:value-of select="'0.001'"/>
                </xsl:attribute>
                </xsl:otherwise>
            </xsl:choose>
            
            <xsl:apply-templates select="node()"/>
        </xsl:copy>
    </xsl:template>

    <xsl:template
        match="Footnote | Note | Br | TextFrame | HyperlinkTextDestination | Group | GraphicLine | Oval | Polygon | Rectangle | Table">
        <xsl:choose>
            <xsl:when
                test="(ancestor::ParagraphStyleRange) and (not(ancestor::CharacterStyleRange) or not(ancestor::CharacterStyleRange[1] = ancestor::ParagraphStyleRange[1]/descendant::CharacterStyleRange))">
                <xsl:element name="CharacterStyleRange">
                    <xsl:attribute name="AppliedCharacterStyle"
                        select="'CharacterStyle/$ID/[No character style]'"/>
                    <xsl:copy>
                        <xsl:apply-templates select="@* | node()"/>
                    </xsl:copy>
                </xsl:element>
            </xsl:when>
            <xsl:otherwise>
                <xsl:variable name="ancestorPara" select="ancestor::ParagraphStyleRange[1]"/>
                <xsl:variable name="precedingProp" select="(ancestor::CharacterStyleRange/preceding::CharacterStyleRange[1][ancestor::ParagraphStyleRange[1] = $ancestorPara]/child::Properties)"/>
                <!-- commented to avoid the leading space issue Azure 5769 on 18-1-2023-->
                <!--<xsl:if test="not(ancestor::CharacterStyleRange/child::Properties)">
                    <xsl:copy-of select="$precedingProp"/>
                </xsl:if>-->
                <xsl:copy>
                    <xsl:apply-templates select="@*|node()"/>
                </xsl:copy>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>


    <xsl:template match="Change[ancestor::Footnote]">
        <xsl:choose>
            <xsl:when test="@ChangeType = 'InsertedText'">
                <xsl:apply-templates/>
            </xsl:when>
            <xsl:otherwise/>
        </xsl:choose>
    </xsl:template>

    <xsl:template match="Note[ancestor::Note]"/>

    <xsl:template match="body">
        <xsl:apply-templates/>
    </xsl:template>

    <!--<xsl:template match="//@WordNumber|//@Wchange|//FormattingChange|//Cell[@Wchange ='deleted_Cell']|HyperlinkTextDestination[@idmltoword = 'true']|XMLElement/@NoTextMarker|//@BookmarkCount|//@ParaNumber|//@ParaInfo|//ParagraphStyleRange/@ParentStory|//@paraLID|//@BookMarkDestination"/>-->
    <!--  added this new condition, if the footnote element doesn't have any child remove the footnote element  -->
    <xsl:template
        match="//@WordNumber | //@Wchange 
        | //FormattingChange | //Cell[@Wchange = 'deleted_Cell'] 
        | HyperlinkTextDestination[@idmltoword = 'true'] | XMLElement/@NoTextMarker 
        | //@BookmarkCount | //@ParaNumber | //@ParaInfo | //ParagraphStyleRange/@ParentStory 
        | //@paraLID | //@BookMarkDestination|Footnote[count(child::*) = 0]"/>
    <!-- Added to revove the tab space between li and p on 6-1-2021 -->
    
    <xsl:template match="ParagraphStyleRange[contains(substring-after(@AppliedParagraphStyle,'ParagraphStyle/'),'notes')][descendant::CharacterStyleRange[lower-case(substring-after(@AppliedCharacterStyle,'CharacterStyle/'))='endnotenumber']|descendant::XMLElement[lower-case(substring-after(@MarkupTag,'XMLTag/'))='endnotenumber']]//Content[1][matches(.,'&#x9;')]">
        <xsl:copy>
        <xsl:value-of select="normalize-space(.)"/>
        </xsl:copy>
    </xsl:template>
<!-- end -->
<!--Added for page break on 19-3-2022-->
    <xsl:template match="ParagraphStyleRange[descendant::Note[Properties/Label/KeyValuePair[@Value='PAGE BREAK']]]">
        <xsl:copy>
            <xsl:apply-templates select="@*|node()"/>
            <CharacterStyleRange AppliedCharacterStyle="CharacterStyle/$ID/[No character style]" ParagraphBreakType="NextPage">
                <Br/>
            </CharacterStyleRange>
        </xsl:copy>
    </xsl:template>
    <!-- Added to avoid to the lowercase on 18-1-2023 -->
    <!-- Added to avoid the CharacterStyleRange[@Capitalization='Normal'] from indd Azure 7424 on 04-04-2023 -->
    <!--lowercase not Changed for change(insert) inside CharacterStyleRange Azure 9449 on 12-7-2023-->
    <xsl:template match="CharacterStyleRange[@Capitalization='Normal'][descendant::FormattingChange or parent::Change[@ChangeType='InsertedText' or parent::Change]]/Content">
        <xsl:variable name="lowercase" select="lower-case(.)"/>
        <xsl:element name="Content">
           <xsl:value-of select="$lowercase"/>
        </xsl:element>
    </xsl:template>
    <!-- End -->
    <!-- Added to remove the empty paragraph for figure on 18-5-2023 -->
    <xsl:template match="XMLElement[substring-after(@MarkupTag,'XMLTag/'),'FigureGroup']/descendant::ParagraphStyleRange[@Wchange='parainserted'][string-length(.) = 0 and not(descendant::Content) and not(descendant::Note)][descendant::CharacterStyleRange[@data-change='parainserted']]"/>
    <xsl:template match="//ParagraphStyleRange[string-length(.) = 0 and not(descendant::Content) and not(descendant::Note)][descendant::CharacterStyleRange[@data-change='parainserted']]"/>
    <!-- end -->
    <!-- Added for math on 26-09-2025 -->
    <xsl:template match="XMLElement[@MarkupTag='XMLTag/figure'][descendant::XMLAttribute[contains(@Name,'href')][contains(@Value,'/Links')]/tokenize(@Value, '/+')[last()]=ancestor::ParagraphStyleRange[1]/descendant::Change[@ChangeType='InsertedText']/descendant::XMLAttribute[@Name='mathName']/@Value]/XMLAttribute[@Name='latex' or @Name='depth' or @Name='height' or @Name='totalheight' or @Name='width']">
        <xsl:variable name="eqname">
            <xsl:value-of select="ancestor::XMLElement[@MarkupTag='XMLTag/figure'][1]/descendant::XMLAttribute[contains(@Name,'href')][contains(@Value,'/Links')]/tokenize(@Value, '/+')[last()]"/>
        </xsl:variable>
        <xsl:element name="XMLAttribute">
            <xsl:apply-templates select="@*"/>
            
                <xsl:if test="self::XMLAttribute[@Name='latex']">
                    <xsl:attribute name="Value">
                    <xsl:choose>
                        <xsl:when test="ancestor::ParagraphStyleRange[1]/descendant::Change[@ChangeType='InsertedText'][descendant::XMLAttribute[@Name='mathName']/@Value = $eqname]/descendant::XMLAttribute[@Name='latex']">
                            <xsl:value-of select="ancestor::ParagraphStyleRange[1]/descendant::Change[@ChangeType='InsertedText'][descendant::XMLAttribute[@Name='mathName']/@Value = $eqname]/descendant::XMLAttribute[@Name='latex']/@Value"/> 
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="self::XMLAttribute[@Name='latex']/@Value"/>
                        </xsl:otherwise>
                    </xsl:choose>
                    </xsl:attribute>
                </xsl:if>
                <xsl:if test="self::XMLAttribute[@Name='depth']">
                    <xsl:attribute name="Value">
                    <xsl:choose>
                        <xsl:when test="ancestor::ParagraphStyleRange[1]/descendant::Change[@ChangeType='InsertedText'][descendant::XMLAttribute[@Name='mathName']/@Value = $eqname]/descendant::XMLAttribute[@Name='depth']">
                            <xsl:value-of select="ancestor::ParagraphStyleRange[1]/descendant::Change[@ChangeType='InsertedText'][descendant::XMLAttribute[@Name='mathName']/@Value = $eqname]/descendant::XMLAttribute[@Name='depth']/@Value"/> 
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="self::XMLAttribute[@Name='depth']/@Value"/>
                        </xsl:otherwise>
                    </xsl:choose>
                    </xsl:attribute>
                </xsl:if>
            <xsl:if test="self::XMLAttribute[@Name='height']">
                <xsl:attribute name="Value">
                <xsl:choose>
                    <xsl:when test="ancestor::ParagraphStyleRange[1]/descendant::Change[@ChangeType='InsertedText'][descendant::XMLAttribute[@Name='mathName']/@Value = $eqname]/descendant::XMLAttribute[@Name='height']">
                        <xsl:value-of select="ancestor::ParagraphStyleRange[1]/descendant::Change[@ChangeType='InsertedText'][descendant::XMLAttribute[@Name='mathName']/@Value = $eqname]/descendant::XMLAttribute[@Name='height']/@Value"/> 
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="self::XMLAttribute[@Name='height']/@Value"/>
                    </xsl:otherwise>
                </xsl:choose>
                </xsl:attribute>
            </xsl:if>
            <xsl:if test="self::XMLAttribute[@Name='totalheight']">
                <xsl:attribute name="Value">
                    <xsl:choose>
                        <xsl:when test="ancestor::ParagraphStyleRange[1]/descendant::Change[@ChangeType='InsertedText'][descendant::XMLAttribute[@Name='mathName']/@Value = $eqname]/descendant::XMLAttribute[@Name='totalheight']">
                            <xsl:value-of select="ancestor::ParagraphStyleRange[1]/descendant::Change[@ChangeType='InsertedText'][descendant::XMLAttribute[@Name='mathName']/@Value = $eqname]/descendant::XMLAttribute[@Name='totalheight']/@Value"/> 
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="self::XMLAttribute[@Name='totalheight']/@Value"/>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:attribute>
            </xsl:if>
            <xsl:if test="self::XMLAttribute[@Name='width']">
                <xsl:attribute name="Value">
                    <xsl:choose>
                        <xsl:when test="ancestor::ParagraphStyleRange[1]/descendant::Change[@ChangeType='InsertedText'][descendant::XMLAttribute[@Name='mathName']/@Value = $eqname]/descendant::XMLAttribute[@Name='width']">
                            <xsl:value-of select="ancestor::ParagraphStyleRange[1]/descendant::Change[@ChangeType='InsertedText'][descendant::XMLAttribute[@Name='mathName']/@Value = $eqname]/descendant::XMLAttribute[@Name='width']/@Value"/> 
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="self::XMLAttribute[@Name='width']/@Value"/>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:attribute>
            </xsl:if>
        </xsl:element>
    </xsl:template>
    <xsl:template match="Change[@ChangeType='InsertedText'][descendant::XMLAttribute[@Name='mathName']/@Value= ancestor::ParagraphStyleRange[1]/descendant::XMLElement[@MarkupTag='XMLTag/figure']/descendant::XMLAttribute[contains(@Name,'href')][contains(@Value,'/Links')]/tokenize(@Value, '/+')[last()]]"/>
    <!-- Bis isync on 26-09-2025 -->
    <!--<xsl:template match="ParagraphStyleRange[descendant::XMLAttribute[contains(@Name,'data-isync')][not(ancestor::Change[@ChangeType='InsertedText'])]][descendant::Change[@ChangeType='InsertedText']/descendant::XMLAttribute[contains(@Name,'data-isync')]]/XMLElement/XMLAttribute[contains(@Name,'data-isync')]">
        <xsl:element name="XMLAttribute">
            <xsl:apply-templates select="@*"/>
            <xsl:if test="self::XMLAttribute[contains(@Name,'data-isync')]">
                <xsl:attribute name="Value">
                    <xsl:value-of select="ancestor::ParagraphStyleRange[1][descendant::XMLAttribute[contains(@Name,'data-isync')][not(ancestor::Change[@ChangeType='InsertedText'])]][descendant::Change[@ChangeType='InsertedText']/descendant::XMLAttribute[contains(@Name,'data-isync')]]/descendant::Change[@ChangeType='InsertedText']/descendant::XMLAttribute[contains(@Name,'data-isync')]/@Value"/>
                </xsl:attribute>
            </xsl:if>
        </xsl:element>
    </xsl:template>-->
    <xsl:template match="XMLElement[@MarkupTag='XMLTag/[No paragraph style]'][descendant::XMLAttribute[contains(@Name,'data-isync')]]">
        <xsl:element name="XMLElement">
            <xsl:apply-templates select="@*"/>
            <xsl:attribute name="MarkupTag">
                <xsl:value-of select="'XMLTag/'"/>
                <xsl:value-of select="ancestor::ParagraphStyleRange[1]/following-sibling::ParagraphStyleRange[not(contains(substring-after(@AppliedParagraphStyle,'ParagraphStyle/'),'[No paragraph style]'))][1]/substring-after(@AppliedParagraphStyle,'ParagraphStyle/')"/>
            </xsl:attribute>
            <xsl:apply-templates select="node()"/>
        </xsl:element>
    </xsl:template>
    <xsl:template match="ParagraphStyleRange[descendant::XMLAttribute[contains(@Name,'data-isync')][not(ancestor::Change[@ChangeType='InsertedText'])]][descendant::Change[@ChangeType='InsertedText']/descendant::XMLAttribute[contains(@Name,'data-isync')]]//XMLElement/XMLAttribute[contains(@Name,'data-isync')]">
        <xsl:variable name="name1"><xsl:value-of select="self::XMLAttribute[contains(@Name,'data-isync')]/@Name"/></xsl:variable>
        <xsl:for-each select="self::XMLAttribute[contains(@Name,'data-isync')]">
            <xsl:variable name="name"><xsl:value-of select="@Name"/></xsl:variable>
        <xsl:element name="XMLAttribute">
            <xsl:apply-templates select="@*"/>
               <xsl:attribute name="Value">
                    <xsl:value-of select="ancestor::ParagraphStyleRange[1][descendant::XMLAttribute[contains(@Name,'data-isync')][not(ancestor::Change[@ChangeType='InsertedText'])]][descendant::Change[@ChangeType='InsertedText']/descendant::XMLAttribute[contains(@Name,'data-isync')]]/descendant::Change[@ChangeType='InsertedText']/descendant::XMLAttribute[contains(@Name,'data-isync')][@Name =$name]/@Value"/>
                </xsl:attribute>
        </xsl:element>
        </xsl:for-each>
    </xsl:template>
    <xsl:template match="ParagraphStyleRange[descendant::XMLAttribute[contains(@Name,'data-isync')][not(ancestor::Change)]][descendant::Change/descendant::XMLAttribute[contains(@Name,'data-isync')]]//Change[@ChangeType='InsertedText'][descendant::XMLAttribute[contains(@Name,'data-isync')]]"/>
</xsl:stylesheet>